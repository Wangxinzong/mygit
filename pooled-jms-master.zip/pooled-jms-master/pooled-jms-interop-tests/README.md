JMS Pool Client Interop tests
----------------------------------------------
This module contains maven submodules that should exercise the JMS Pool using various JMS client implementations.
