Pooled-JMS

For a basic overview of the Pooled-JMS project see the docs directory.

For examples of using the JMS Pool, see the examples directory.

The JMS pool artifacts and required dependencies can be found
in the lib directory.
