## 安装

### 使用要求

qingstor-sdk-java 适用于 JDK1.6+。

### 下载

手动下载最新版本的 JAR 或通过 Maven 下载

```
<dependency>
  <groupId>com.yunify</groupId>
	<artifactId>qingstor.sdk.java</artifactId>
	<version> [latest version] </version>
</dependency>
```

[在 Maven 仓库中心获取最新的版本](http://search.maven.org/#search%7Cgav%7C1%7Cg%3A%22com.yunify%22%20AND%20a%3A%22qingstor.sdk.java%22)

[你也可以从这个仓库中下载](https://github.com/yunify/qingstor-sdk-java/releases)
